
export type PropDataItem = {
  prop: string;
  type: string;
  defaultValue: string;
  description: string;
};
